for i in {0..4}
do
    git rev-parse HEAD~$i || echo "no more commits"
done